<?php

    $con = mysqli_connect("localhost", "root", "@stephen12#xampp", "fms");
    if (mysqli_connect_errno()) {
        echo "failed to connect: ".mysqli_connect_errno();
    }

?>